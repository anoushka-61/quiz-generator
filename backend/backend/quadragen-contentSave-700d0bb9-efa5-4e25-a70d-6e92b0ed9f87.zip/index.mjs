import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { TextractClient, StartDocumentTextDetectionCommand, GetDocumentTextDetectionCommand } from '@aws-sdk/client-textract';

const s3 = new S3Client({});
const textract = new TextractClient({});

export const handler = async (event) => {
    try {
        const record = event.Records[0];
        const bucket = record.s3.bucket.name;
        const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
        console.log(`Processing file: ${key} from bucket: ${bucket}`);

        if (key.endsWith('.pdf')) {
            await processPDF(bucket, key);
        } 
        else {
            console.log(`Unsupported file type for key: ${key}`);
        }
    } catch (error) {
        console.error('Error processing file:', error);
    }
};


async function processPDF(bucket, key) {
    const startParams = {
        DocumentLocation: {
            S3Object: { Bucket: bucket, Name: key }
        }
    };

    const { JobId } = await textract.send(new StartDocumentTextDetectionCommand(startParams));
    console.log(`Textract Job Started: ${JobId}`);

    let jobStatus = '';
    do {
        await new Promise(resolve => setTimeout(resolve, 5000));
        const jobResult = await textract.send(new GetDocumentTextDetectionCommand({ JobId }));
        jobStatus = jobResult.JobStatus;
        console.log(`Textract Job Status: ${jobStatus}`);
    } while (jobStatus === 'IN_PROGRESS');

    if (jobStatus === 'SUCCEEDED') {
        const result = await textract.send(new GetDocumentTextDetectionCommand({ JobId }));
        const extractedText = result.Blocks
            .filter(block => block.BlockType === 'LINE')
            .map(block => block.Text)
            .join('\n');

        const extractedKey = key.replace('content/', 'extractedContent/').replace(/\.pdf$/, '.txt');
        await s3.send(new PutObjectCommand({
            Bucket: bucket,
            Key: extractedKey,
            Body: extractedText,
            ContentType: 'text/plain'
        }));

        console.log(`Extracted text saved to: ${bucket}/${extractedKey}`);
    } else {
        console.error('Textract job failed:', jobStatus);
    }
}


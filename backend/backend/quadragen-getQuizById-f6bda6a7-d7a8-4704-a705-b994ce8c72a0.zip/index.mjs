import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';

const s3Client = new S3Client();

export const handler = async (event) => {
  try {
    const { courseId } = event.queryStringParameters;

    if (!courseId) {
      return {
        statusCode: 400,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type',
        },
        body: JSON.stringify({ message: 'courseId is required' }),
      };
    }

    const bucketName = "quadragen-content-files"; // Bucket name from environment variable
    const fileKey = `quizes/${courseId}.json`;

    const params = {
      Bucket: bucketName,
      Key: fileKey,
    };

    const command = new GetObjectCommand(params);
    const result = await s3Client.send(command);

    const body = await result.Body.transformToString();
    console.log("body", body);
    const quizData = JSON.parse(body);
let {quizTitle, sections} = quizData;
let responseData = {
  data:{
    quiz:sections,
    quizTitle
    
  }
}
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: JSON.stringify(responseData),
    };
  } catch (error) {
    console.error('Error fetching quiz:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: JSON.stringify({ message: 'Internal Server Error', error: error.message }),
    };
  }
};

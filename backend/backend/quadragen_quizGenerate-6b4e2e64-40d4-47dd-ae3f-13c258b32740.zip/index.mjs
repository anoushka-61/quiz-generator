import { TextractClient, StartDocumentTextDetectionCommand, GetDocumentTextDetectionCommand } from "@aws-sdk/client-textract";
import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";
import { S3Client, GetObjectCommand, PutObjectCommand, HeadObjectCommand } from "@aws-sdk/client-s3";

const S3_BUCKET = "quadragen-content-files";
const coursePath = "content";
const extractedTextPath = "extractedContent";
const quizPath = "quizes";
const textractClient = new TextractClient({});
const bedrockClient = new BedrockRuntimeClient({});
const s3Client = new S3Client({});


export const handler = async (event) => {
  
let response = {};
    let returnBody = {
        statusCode: 200,
        body: "",
        headers: {
            "content-type": "application/json",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST",
        },
    };
    
  try {

    let extractedText;
    console.log("type", typeof event, "event", event)
    let bodyData = JSON.parse(event.body);
    
    const {courseFile,numSections, questionsPerSection,difficulty, totalMarks } = bodyData;
    let marksPerQuestion =  (numSections * questionsPerSection)/totalMarks;
      const courseFileName = courseFile.split("/")[2];//courseid_timestamp.pdf
      const courseFileKey = `${coursePath}/${courseFileName}`;
      const extractedTextFileName = courseFileName.replace(/\.[^.]+$/, ".txt");//courseid_timestamp.txt
      const extractedFileKey = `${extractedTextPath}/${extractedTextFileName}`;
      const quizFileKey = `${quizPath}/${courseFileName.replace(/\.[^.]+$/, ".json")}`; //quizes/courseid_timestamp.json

    try {
      await s3Client.send(new HeadObjectCommand({ Bucket: S3_BUCKET, Key: extractedFileKey }));
      console.log("Extracted text exists in S3, fetching...");

      const s3Response = await s3Client.send(new GetObjectCommand({ Bucket: S3_BUCKET, Key: extractedFileKey }));
      extractedText = await s3Response.Body.transformToString();
    } catch (error) {
      if (error.name === "NotFound") {
        console.log("Extracted text not found, running Textract...");

        const startResponse = await textractClient.send(
          new StartDocumentTextDetectionCommand({
            DocumentLocation: { S3Object: { Bucket: S3_BUCKET, Name: courseFileKey } },
          })
        );

        const jobId = startResponse.JobId;
        console.log("Textract Job Started:", jobId);

        let jobStatus = "IN_PROGRESS";
        let response;

        while (jobStatus === "IN_PROGRESS") {
          await new Promise((resolve) => setTimeout(resolve, 5000));
          response = await textractClient.send(new GetDocumentTextDetectionCommand({ JobId: jobId }));
          jobStatus = response.JobStatus;
          console.log("Job Status:", jobStatus);
        }

        extractedText = response.Blocks
          .filter((block) => block.BlockType === "LINE")
          .map((line) => line.Text)
          .join(" ");

        await s3Client.send(
          new PutObjectCommand({
            Bucket: S3_BUCKET,
            Key: extractedFileKey,
            Body: extractedText,
          })
        );
      } else {
        console.error("Error checking S3:", error);
        throw error;
      }
    }

    //  Dynamically calculate max_tokens (no capping)
    const avgTokensPerQuestion = 150; // Estimated tokens per question (including options)
    // let maxTokens = numSections * questionsPerSection * avgTokensPerQuestion;
    // let min = Math.max(maxTokens, 4000)
//  maxTokens = Math.min(min, 190000);
    //  Enforce JSON output
let maxTokens = 190000;
const prompt = `"${extractedText}"
Generate a JSON quiz with ${numSections}, each section having ${questionsPerSection} questions of ${difficulty} difficulty based on the provided content without any comments.
ensure the format below:
{"quizTitle": "Quiz Title",
"sections": [
  {
    "title": "Section Title",
    "questions": [
      {
        "question": "Question text",
        "options": ["option1", "option2", "option3", "option4"],
        "correct_answer": "option2",
      }
    ]
  }
]
}`
    const quizResponse = await bedrockClient.send(
      new InvokeModelCommand({
        modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
        contentType: "application/json",
        accept: "application/json",
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          messages: [{ role: "user", content: prompt }],
          max_tokens: maxTokens, // Fully dynamic
          // temperature: 1,
        // top_p: 0.9,
        }),
      })
    );
let stringifiedQuizResponse = String.fromCharCode(...quizResponse.body);
console.log("Quiz response:", stringifiedQuizResponse);
    const quizText = stringifiedQuizResponse.replace(/\\n|\/\//g, '').replace(/\s{2,}/g, " ").trim();
    let quiz = JSON.parse(quizText)["content"][0].text.trim();
    let parsedQuiz = JSON.parse(quiz);
let sections = parsedQuiz.sections ;
    

    let toTalQuestions = 0;
let sectionsWithMarks = parsedQuiz.sections.map(section => {
  toTalQuestions += section.questions.length;
  let sectionModifiedQuestions = section.questions.map((question) => {
    question.is_active = true;
    return question;
  })
  section.questions = sectionModifiedQuestions;
  section.is_active = true;
  return section;
});

sectionsWithMarks = sectionsWithMarks.map(section => {
  let sectionModifiedQuestions = section.questions.map((question) => {
    question.marks = Number(totalMarks)/toTalQuestions; 
    return question;
  })
  section.questions = sectionModifiedQuestions;
  return section;
});

await s3Client.send(
  new PutObjectCommand({
    Bucket: S3_BUCKET,
    Key: quizFileKey,
    Body: JSON.stringify({quizTitle:parsedQuiz.quizTitle,sections:sectionsWithMarks}),
    ContentType: "application/json",
  })
);


response.data = {
  status: "success",
  message: "Quiz uploaded successfully",
  quizFile: `${S3_BUCKET}/${quizFileKey}`,
  quiz: sectionsWithMarks,
  quizTitle:parsedQuiz.quizTitle
};

  } catch (error) {
    console.error("Error:", error);
    response = {
      error: {
          code: error.response ? error.response.status : 500,
          custom_code: error.response ? error.response.status : 500,
          message: error.message,
      },
  };
  }
  return {
    statusCode: response.error ? response.error.code : returnBody.statusCode,
    body: JSON.stringify(response),
    headers: returnBody.headers,
};
};

'use strict';
import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import { BedrockRuntimeClient, InvokeModelWithResponseStreamCommand } from '@aws-sdk/client-bedrock-runtime';
import { Readable } from 'stream';

const s3Client = new S3Client({ region: 'us-east-1' });
const bedrockClient = new BedrockRuntimeClient({ region: 'us-east-1' });
const knowledgeBaseId = "AJAVN6CKGH";
const anthropicModelId = "anthropic.claude-3-sonnet-20240229-v1:0";
// Helper to stream S3 object data into a string
async function streamToString(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf-8');
}

// Helper to fetch content from S3
async function getQuizResponses(bucket, key) {
  const command = new GetObjectCommand({ Bucket: bucket, Key: key });
  const { Body } = await s3Client.send(command);
  const data = await streamToString(Body);
  return JSON.parse(data);
}

// Helper to upload analysis to S3
async function uploadAnalysisToS3(bucket, key, analysisData) {
  const command = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: JSON.stringify(analysisData, null, 2),
    ContentType: 'application/json'
  });
  await s3Client.send(command);
}

async function processStream(responseStream) {
  let result = "";
  for await (const chunk of responseStream) {
    const message = chunk.chunk?.bytes ? Buffer.from(chunk.chunk.bytes).toString('utf-8') : '';
    let messageConverted = message.replace(/\\n|\/\//g, '').replace(/\s{2,}/g, " ").trim();
    messageConverted = JSON.parse(messageConverted);
    if (messageConverted?.delta?.text) {
      result += messageConverted.delta.text;
    }
  }
  console.log("result", result);
  return result;
}

// Helper to generate analysis with Bedrock Anthropics
async function getStrengthWeaknessAnalysis(responses) {
  const prompt = `\nHuman: Analyze the following quiz responses and provide assessment analysis in JSON format as shown below  without any comments:\n${JSON.stringify(responses)}\nFormat:
{
  "score": number,
  "maxMarks": number,
  "sections": [{ "name": string, "secScore": number, "maxMarks": number }],
  "strengths": [{ "topic": string, "percentage": number }],
  "weaknesses": [{ "topic": string, "percentage": number }]
}
Assistant:`;

  const command = new InvokeModelWithResponseStreamCommand({
    modelId: anthropicModelId,
    body: JSON.stringify({ 
      anthropic_version: "bedrock-2023-05-31",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 4000, // Fully dynamic
     })
  });

  const response = await bedrockClient.send(command);
  return processStream(response.body);


}

// Helper to generate Course Recommendations
async function getCourseRecommendations(responses) {
  const prompt = `\nHuman: Based on these quiz responses, suggest personalized course recommendations using the knowledge base (${knowledgeBaseId}) in JSON format as shown below  without any comments:\n${JSON.stringify(responses)}\nFormat:
{
  "courses": [{ "title": string, "description": string, "image": string }]
}
Assistant:`;
  const command = new InvokeModelWithResponseStreamCommand({
    modelId: anthropicModelId,
    body: JSON.stringify({ 
      anthropic_version: "bedrock-2023-05-31",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 4000, // Fully dynamic
    })
  });

  const response = await bedrockClient.send(command);
  return processStream(response.body);
}

export const handler = async (event) => {
  try {
    const s3Event = event.Records[0].s3;
    const bucket = s3Event.bucket.name;
    const key = decodeURIComponent(s3Event.object.key.replace(/\+/g, ' '));
console.log("key",key)
    if (!key.startsWith('learnerResponses/')) {
      console.log(`Ignoring file not in learnerResponses folder: ${key}`);
      return;
    }

    const responses = await getQuizResponses(bucket, key);
console.log("responses", responses);
    const [analysis, recommendations] = await Promise.all([
      getStrengthWeaknessAnalysis(responses),
      getCourseRecommendations(responses)
    ]);

    const assessmentData = {
      firstName: responses.firstName,
      assessmentName: responses.assessmentName,
      ...JSON.parse(analysis),
      ...JSON.parse(recommendations)
    };

console.log("analysis", analysis);
console.log("recommendations",recommendations);
  

    const analysisKey = key.replace('learnerResponses/', 'learnerCoursesRecommendation/');
    await uploadAnalysisToS3(bucket, `${analysisKey}.json`, assessmentData);
console.log(`Analysis uploaded to: ${analysisKey}`);
console.log("recommendations", recommendations);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Analysis uploaded successfully', analysisKey })
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal Server Error', error: error.message })
    };
  }
};
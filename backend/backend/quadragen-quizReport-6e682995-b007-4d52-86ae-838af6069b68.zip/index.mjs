'use strict';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { Readable } from 'stream';

const s3Client = new S3Client({ region: process.env.AWS_REGION });

// Helper function to convert stream to string
async function streamToString(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf-8');
}

export const handler = async (event) => {
  try {
    const bucketName = "quadragen-content-files"
    const { quizFileKey } = JSON.parse(event.body);
const fileKey = `learnerCoursesRecommendation/${quizFileKey}.json`
    if ( !fileKey) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Missing  quizFileKey in request body' })
      };
    }

    const command = new GetObjectCommand({
      Bucket: bucketName,
      Key: fileKey
    });

    const { Body } = await s3Client.send(command);
    const fileContent = await streamToString(Body);

  

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*", // Allow all origins
        "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
      body: JSON.stringify({ message: 'File fetched successfully', data: JSON.parse(fileContent) })
    };

  } catch (error) {
    console.error('Error fetching file from S3:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal Server Error', error: error.message })
    };
  }
};
